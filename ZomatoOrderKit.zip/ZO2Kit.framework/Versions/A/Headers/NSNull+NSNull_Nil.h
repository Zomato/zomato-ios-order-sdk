//
//  NSNull+NSNull_Nil.h
//  ZMTApiManageriOS
//
//  Created by Udit Gupta on 20/10/15.
//  Copyright © 2015 Zomato. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSNull (NSNull_Nil)

@end
